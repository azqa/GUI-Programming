import React from 'react';
export const DeviceContext = React.createContext();
